﻿#!/bin/sh
cd "$(dirname "$0")"

echo "请选择操作："
echo "1) 安装"
echo "2) 卸载"
printf "请输入 [1/2]: "

read choice </dev/tty

case "$choice" in
    1)
        echo "== 安装..."

        mkdir -p /usr/lib/lua/luci/model/cbi/clientstatus
        mkdir -p /usr/lib/lua/luci/controller
        mkdir -p /usr/lib/lua/luci/view
        mkdir -p /usr/lib/lua/luci/i18n
        mkdir -p /usr/bin
        mkdir -p /etc/init.d
        mkdir -p /etc/config

        mv -f settings.lua           /usr/lib/lua/luci/model/cbi/clientstatus/
        mv -f clientstatus.lua      /usr/lib/lua/luci/controller/
        mv -f clientstatus.htm      /usr/lib/lua/luci/view/
        mv -f clientstatus.zh-cn.lmo /usr/lib/lua/luci/i18n/
        mv -f clientstatus.sh       /usr/bin/
        mv -f clientstatus.init     /etc/init.d/clientstatus
        mv -f clientstatus.conf     /etc/config/clientstatus

        chmod +x /usr/bin/clientstatus.sh
        chmod +x /etc/init.d/clientstatus

        chown -R root:root \
            /usr/lib/lua/luci \
            /usr/bin/clientstatus.sh \
            /etc/init.d/clientstatus \
            /etc/config/clientstatus

        /etc/init.d/clientstatus enable
        /etc/init.d/clientstatus start
        [ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd restart

        echo "== 安装完成 ✅ =="
        ;;

    2)
        echo "== 卸载..."

        /etc/init.d/clientstatus stop 2>/dev/null || true
        /etc/init.d/clientstatus disable 2>/dev/null || true

        rm -f /usr/lib/lua/luci/model/cbi/clientstatus/settings.lua
        rm -f /usr/lib/lua/luci/controller/clientstatus.lua
        rm -f /usr/lib/lua/luci/view/clientstatus.htm
        rm -f /usr/lib/lua/luci/i18n/clientstatus.zh-cn.lmo
        rm -f /usr/bin/clientstatus.sh
        rm -f /etc/init.d/clientstatus
        rm -f /etc/config/clientstatus

        echo "== 卸载完成 ✅ =="
        ;;

    *)
        echo "无效选择"
        exit 1
        ;;
esac