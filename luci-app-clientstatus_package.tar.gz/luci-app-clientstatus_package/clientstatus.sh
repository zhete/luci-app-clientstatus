#!/bin/sh
# clientstatus main script

CLIENTSTATUS_FILE="/tmp/clientstatus"
REFRESH_INTERVAL=30

log() {
    logger -t "clientstatus" "$1"
}

scan_clients() {
    # Scan ARP table and DHCP leases
    > "$CLIENTSTATUS_FILE"
    
    # Read ARP table
    while read -r line; do
        set -- $line
        if [ $# -ge 6 ]; then
            ip="$1"
            mac="$4"
            iface="$6"
            echo "CLIENT|$mac|$ip|$iface|unknown|0|0|0" >> "$CLIENTSTATUS_FILE"
        fi
    done < /proc/net/arp
    
    # Update with DHCP info
    if [ -f /tmp/dhcp.leases ]; then
        while read -r line; do
            set -- $line
            if [ $# -ge 4 ]; then
                mac="$2"
                ip="$3"
                hostname="$4"
                # Update hostname in clientstatus file
                sed -i "s/CLIENT|$mac|[^|]*|[^|]*|[^|]*/CLIENT|$mac|$ip|br-lan|$hostname/" "$CLIENTSTATUS_FILE"
            fi
        done < /tmp/dhcp.leases
    fi
}

main_loop() {
    log "clientstatus started"
    while true; do
        scan_clients
        sleep "$REFRESH_INTERVAL"
    done
}

# Main
main_loop
